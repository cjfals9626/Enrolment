package service;

import persistence.dao.AdminDAO;
import persistence.dao.StudentDAO;
import persistence.dto.AdminDTO;
import persistence.dto.StudentDTO;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class StudentService {
    private final StudentDAO studentDAO;

    public StudentService(StudentDAO studentDAO) {
        this.studentDAO = studentDAO;
    }

    public List<StudentDTO> findStudentAll(){
        List<StudentDTO> all = studentDAO.findStudentAll();
        return all;
    }

    public void insertStudent(){
        Scanner s = new Scanner(System.in);
        System.out.print("input id : ");
        try{
            studentDAO.insertStudent(s.nextInt());
        }catch (InputMismatchException e){
            e.printStackTrace();
        }

    }

    public void updateStudent(){
        Scanner s = new Scanner(System.in);
        System.out.print("input id : ");
        try{
            studentDAO.updateStudent(s.nextInt());
        }catch (InputMismatchException e){
            e.printStackTrace();
        }
    }
}
