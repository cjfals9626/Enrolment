package service;

import persistence.MyBatisConnectionFactory;
import persistence.dao.ProfessorDAO;
import persistence.dao.SubjectNotOpenDAO;
import persistence.dao.SubjectOpenDAO;
import persistence.dto.*;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class SubjectOpenService {
    SubjectOpenDAO subjectOpenDAO;
    SubjectNotOpenDAO subjectNotOpenDAO;

    public SubjectOpenService(SubjectOpenDAO subjectOpenDAO, SubjectNotOpenDAO subjectNotOpenDAO){
        this.subjectOpenDAO = subjectOpenDAO;
        this.subjectNotOpenDAO = subjectNotOpenDAO;
    }

    public List<SubjectOpenDTO> getSubjectOpenAll(){
        List<SubjectOpenDTO> all = subjectOpenDAO.getSubjectOpenAll();
        return all;
    }

    public List<SubjectOpenDTO> getSubjectOpenProfessorAll(){
        Scanner s = new Scanner(System.in);
        System.out.print("담당 과목 조회할 교수 이름 : ");
        String professor_name = s.next();
        ProfessorDAO professorDAO = new ProfessorDAO();
        List<ProfessorDTO> allProfessor = professorDAO.findProfessorAll();
        for(ProfessorDTO dtos : allProfessor){
            if(professor_name.equals(dtos.getName())){
                List<SubjectOpenDTO> all = subjectOpenDAO.getSubjectOpenProfessorAll(dtos.getId());
                return all;
            }
        }
        System.out.println("검색결과가 없습니다");
        return null;
    }

    public List<SubjectOpenDTO> getSubjectOpenGradeAll(){
        Scanner s = new Scanner(System.in);
        System.out.print("input grade : ");
        List<SubjectOpenDTO> all = subjectOpenDAO.getSubjectGradeOpenAll(s.nextInt());
        return all;
    }

    public List<SubjectOpenDTO> getSubjectOpenProfessorAndGradeAll(){
            Scanner s = new Scanner(System.in);
            System.out.print("과목 조회할 교수 이름 : ");
            String professor_name = s.next();
            System.out.print("해당 교수의 과목 중 조회할 학년 : ");
            int possible_grade = s.nextInt();
        ProfessorDAO professorDAO = new ProfessorDAO();
        List<ProfessorDTO> allProfessor = professorDAO.findProfessorAll();
        for(ProfessorDTO dtos : allProfessor){
            if(professor_name.equals(dtos.getName())){
                List<SubjectOpenDTO> all = subjectOpenDAO.getSubjectOpenProfessorAndGradeAll(dtos.getId(), possible_grade);
                return all;
            }
        }
        System.out.println("검색결과가 없습니다");
        return null;
    }

    public void openSubject(){
        SubjectOpenDTO subjectOpenDTO = new SubjectOpenDTO();
        Scanner s = new Scanner(System.in);
        System.out.print("input subject_id : ");
        int subject_id = s.nextInt();
        List<SubjectNotOpenDTO> all = subjectNotOpenDAO.getSubjectNotOpenAll();
        boolean open_flag = false;
        for(SubjectNotOpenDTO dtos : all){
            if(subject_id == dtos.getSubject_id()){
                if(dtos.isOpen()){
                    System.out.println("이미 열린 과목입니다");
                    return;
                }
                open_flag = true;
                break;
            }
        }
        if(!open_flag){
            System.out.println("존재하지 않는 과목입니다");
            return;
        }
        System.out.print("input max_people : ");
        int max_people = s.nextInt();
        System.out.print("input subject_plan : ");
        String subject_plan = s.next();
        System.out.print("input plan_modify_date : ");
        Date plan_modify_date = Date.valueOf(s.next());
        System.out.print("input credit : ");
        int credit = s.nextInt();
        System.out.print("input day : ");
        String day = s.next();
        System.out.print("input time : ");
        String time = s.next();
        System.out.print("input classroom : ");
        String classroom = s.next();
        System.out.print("input professor_user_id : ");
        int professor_user_id = s.nextInt();
        ProfessorDAO professorDAO = new ProfessorDAO();
        List<ProfessorDTO> allProfessor = professorDAO.findProfessorAll();
        boolean flag = false;
        for(ProfessorDTO dtos : allProfessor){
            if(professor_user_id == dtos.getId()){
                flag = true;
            }
        }
        if(!flag) {
            System.out.println("존재하지 않는 id");
            return;
        }
        subjectOpenDTO.setSubject_id(subject_id);
        subjectOpenDTO.setMax_people(max_people);
        subjectOpenDTO.setSubject_plan(subject_plan);
        subjectOpenDTO.setPlan_modify_date(plan_modify_date);
        subjectOpenDTO.setCredit(credit);
        subjectOpenDTO.setDay(day);
        subjectOpenDTO.setTime(time);
        subjectOpenDTO.setClassroom(classroom);
        subjectOpenDTO.setProfessor_user_id(professor_user_id);
        subjectOpenDAO.openSubject(subjectOpenDTO);
    }

    public void updateSubjectOpen(){
        Scanner s = new Scanner(System.in);
        System.out.print("input subject_id : ");
        int subject_id = s.nextInt();
        List<SubjectOpenDTO> all = subjectOpenDAO.getSubjectOpenAll();
        boolean flag = false;
        for(SubjectOpenDTO dtos : all){
            if(subject_id == dtos.getSubject_id()){
                flag = true;
            }
        }
        if(!flag) {
            System.out.println("존재하지 않는 id");
            return;
        }
        System.out.print("input subject_name : ");
        String subject_name = s.next();
        System.out.print("input max_people : ");
        int max_people = s.nextInt();
        System.out.print("input possible_grade : ");
        int possible_grade = s.nextInt();
        System.out.print("input credit : ");
        int credit = s.nextInt();
        System.out.print("input day : ");
        String day = s.next();
        System.out.print("input time : ");
        String time = s.next();
        System.out.print("input classroom : ");
        String classroom = s.next();
        subjectOpenDAO.updateSubjectOpen(subject_id, subject_name, max_people, possible_grade, credit, day, time, classroom);
    }

    public void updateSubjectPlanModifySubjectOpen(){
        Scanner s = new Scanner(System.in);
        System.out.print("input subject_id : ");
        int subject_id = s.nextInt();
        List<SubjectOpenDTO> all = subjectOpenDAO.getSubjectOpenAll();
        boolean flag = false;
        for(SubjectOpenDTO dtos : all){
            if(subject_id == dtos.getSubject_id()){
                flag = true;
            }
        }
        if(!flag){
            System.out.println("존재하지 않는 id");
            return;
        }
        System.out.print("input subject_plan_modify : ");
        String subject_plan_modify = s.next();
        subjectOpenDAO.updateSubjectPlanModifySubjectOpen(subject_id, Date.valueOf(subject_plan_modify));
    }

    public void updateSubjectPlanSubjectOpen(){
        Scanner s = new Scanner(System.in);
        System.out.print("input subject_id : ");
        int subject_id = s.nextInt();
        List<SubjectOpenDTO> all = subjectOpenDAO.getSubjectOpenAll();
        boolean flag = false;
        for(SubjectOpenDTO dtos : all){
            if(subject_id == dtos.getSubject_id()){
                flag = true;
            }
        }
        if(!flag){
            System.out.println("존재하지 않는 id");
            return;
        }
        System.out.print("input subject_plan : ");
        s.nextLine();
        String subject_plan = s.nextLine();
        System.out.println(subject_plan);
        subjectOpenDAO.updateSubjectPlanSubjectOpen(subject_id, subject_plan);
    }

    public void deleteSubjectOpen(){
        Scanner s = new Scanner(System.in);
        System.out.print("input subject_id : ");
        int subject_id = s.nextInt();
        List<SubjectOpenDTO> all = subjectOpenDAO.getSubjectOpenAll();
        boolean flag = false;
        for(SubjectOpenDTO dtos : all){
            if(subject_id == dtos.getSubject_id()){
                flag = true;
            }
        }
        if(!flag) {
            System.out.println("존재하지 않는 id");
            return;
        }
        subjectOpenDAO.deleteSubjectOpen(subject_id);
    }

    public void printPerProfessorClassStudent(){
        Scanner s = new Scanner(System.in);
        System.out.print("수강생 조회할 개설 교과목 ID : ");
        int subject_id = s.nextInt();
        int start = 0;
        int count = subjectOpenDAO.getPerProfessorClassStudentCount(subject_id);
        int page = count / 2 + count % 2;
        while (true)
        {
            System.out.println("최대 페이지 : " + page);
            List<PerProfessorClassDTO> perProfessorClassDTOS = subjectOpenDAO.getPerProfessorClass(subject_id);
            System.out.print("input page (exit 0 이하) : ");
            start = s.nextInt();
            if(start <= 0 || start > page)
                break;
            List<PerProfessorClassStudentDTO> perProfessorClassStudentDTOS = null;
            for(PerProfessorClassDTO dtos : perProfessorClassDTOS){
                if(dtos.getSubject_id() == subject_id){
                    perProfessorClassStudentDTOS = subjectOpenDAO.getPerProfessorClassStudent(subject_id, 2 * (start - 1));
                    break;
                }
            }
            perProfessorClassStudentDTOS.stream().forEach(v -> System.out.println("v.toString() = " + v.toString()));
        }
    }
}
