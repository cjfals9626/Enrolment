package service;

import persistence.dao.ProfessorDAO;
import persistence.dto.ProfessorDTO;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class ProfessorService {
    private final ProfessorDAO professorDAO;

    public ProfessorService(ProfessorDAO professorDAO) {
        this.professorDAO = professorDAO;
    }
    public List<ProfessorDTO> findProfessorAll() {
        List<ProfessorDTO> all = professorDAO.findProfessorAll();
        return all;
    }

    public void insertProfessor(){
        Scanner s = new Scanner(System.in);
        System.out.print("input id : ");
        try{
            professorDAO.insertProfessor(s.nextInt());
        }catch (InputMismatchException e){
            e.printStackTrace();
        }
    }

    public void updateProfessor(){
        Scanner s = new Scanner(System.in);
        System.out.print("input id : ");
        try{
            professorDAO.updateProfessor(s.nextInt());
        }catch (InputMismatchException e){
            e.printStackTrace();
        }
    }
}
