package service;

import persistence.dao.SubjectEnrollDAO;
import persistence.dao.SubjectOpenDAO;
import persistence.dto.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

public class SubjectEnrollService {
    SubjectEnrollDAO subjectEnrollDAO;
    Scanner s = new Scanner(System.in);

    public SubjectEnrollService(SubjectEnrollDAO subjectEnrollDAO){
        this.subjectEnrollDAO = subjectEnrollDAO;
    }

    public void updateEnrollTime(){

        System.out.print("수정할 교과목의 학년 : ");
        int possible_grade = s.nextInt();
        System.out.print("수강 신청 시작 날짜 yyyy-mm-dd : ");
        String enroll_time_start = s.next();
        System.out.print("수강 신청 끝 날짜 yyyy-mm-dd : ");
        String enroll_time_end = s.next();
        if(enroll_time_end.compareTo(enroll_time_start) < 0){
            System.out.println("잘못된 날짜설정입니다");
            return;
        }
        subjectEnrollDAO.updateSubjectEnrollTime(Date.valueOf(enroll_time_start), Date.valueOf(enroll_time_end), possible_grade);
    }

    public void insertSubjectEnrollTakeClassState(){
        List<StudentDTO> studentAll = subjectEnrollDAO.getStudentAll();
        System.out.print("수강 신청할 학생 ID : ");
        int student_user_id = s.nextInt();
        boolean user_flag = false;
        for(StudentDTO dto : studentAll){
            if(student_user_id == dto.getId()){
                user_flag = true;
                break;
            }
        }
        if(!user_flag)
        {
            System.out.println("존재하지 않는 ID입니다.");
            return;
        }
        System.out.print("해당 학생이 수강 신청할 과목 : ");
        int subject_id = s.nextInt();
        boolean subject_flag = false;
        boolean max_people_flag = false;
        int number_people = 0;
        String day = "";
        String time = "";
        List<SubjectEnrollDTO> subjectEnrollDTOS = subjectEnrollDAO.getSubjectEnroll();
        for(SubjectEnrollDTO subjectEnrollDTO : subjectEnrollDTOS){
            if(subject_id == subjectEnrollDTO.getSubject_id()){
                subject_flag = true;
                day = subjectEnrollDTO.getDay();
                time = subjectEnrollDTO.getTime();
                java.util.Date now = new java.util.Date();
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                now = java.sql.Date.valueOf(format.format(now));
                if(subjectEnrollDTO.getEnroll_time_start() == null || subjectEnrollDTO.getEnroll_time_end() == null) {
                    System.out.println("수강신청 날짜 없음");
                    return;
                }
                if(subjectEnrollDTO.getEnroll_time_start().compareTo(now) <= 0 && subjectEnrollDTO.getEnroll_time_end().compareTo(now) >= 0) {
                    number_people = subjectEnrollDTO.getNumber_people();
                    if(number_people < subjectEnrollDTO.getMax_people()){
                        max_people_flag = true;
                        break;
                    }
                    else{
                        System.out.println("최대 수강 인원을 초과하였습니다");
                        return;
                    }
                }else if(!max_people_flag){
                    System.out.println("신청 불가능");
                    return;
                }
            }
        }
        if (!subject_flag){
            System.out.println("신청 불가능");
            return;
        }
        List<MySubjectEnrollDTO> mySubjectEnrollDTO = subjectEnrollDAO.getMySubjectEnroll(student_user_id);
        subjectEnrollDTOS = subjectEnrollDAO.getSubjectEnroll();
        for(MySubjectEnrollDTO dto : mySubjectEnrollDTO) {
            if(day.equals(dto.getDay())) {
                for (int i = 0; i < time.length(); i++) {
                    for (int j = 0; j < dto.getTime().length(); j++) {
                        if (time.charAt(i) == dto.getTime().charAt(j)) {
                            System.out.println("동일한 시간 수강신청입니다");
                            return;
                        }
                    }
                }
            }

        }
        subjectEnrollDAO.insertSubjectEnrollTakeClassState(student_user_id, subject_id, ++number_people);
    }

    public List<SubjectEnrollDTO> getSubjectEnroll(){
        List<SubjectEnrollDTO> subjectEnrollDTOS = subjectEnrollDAO.getSubjectEnroll();
        return subjectEnrollDTOS;
    }

    public List<MySubjectEnrollDTO> getMySubjectEnroll(){
        System.out.print("수강 신청 목록 조회할 학생 ID : ");
        List<MySubjectEnrollDTO> all = subjectEnrollDAO.getMySubjectEnroll(s.nextInt());
        return all;
    }

    public void deleteSubjectEnroll(){
        System.out.print("수강 신청 삭제할 학생 ID : ");
        int student_user_id = s.nextInt();
        System.out.print("해당 학생의 수강 신청 목록에서 삭제할 과목 ID : ");
        int subject_id = s.nextInt();
        List<StudentDTO> studentAll = subjectEnrollDAO.getStudentAll();
        boolean user_flag = false;
        for(StudentDTO dto : studentAll){
            if(student_user_id == dto.getId()){
                user_flag = true;
                break;
            }
        }
        boolean subject_flag = false;
        int number_people = 0;
        List<SubjectEnrollDTO> subjectEnrollDTOS = subjectEnrollDAO.getSubjectEnroll();
        for(SubjectEnrollDTO subjectEnrollDTO : subjectEnrollDTOS){
            if(subject_id == subjectEnrollDTO.getSubject_id()){
                number_people = subjectEnrollDTO.getNumber_people();
                subject_flag = true;
                break;
            }
        }
        if(user_flag && subject_flag)
            subjectEnrollDAO.deleteSubjectEnroll(student_user_id, subject_id, --number_people);
    }
}