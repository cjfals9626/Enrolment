package persistence.dto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PerProfessorClassDTO {
    private int professor_user_id;
    private int subject_id;
}
